import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data_set = pd.read_csv("dataset.csv")
drop_dataframe = data_set.dropna()

winter = drop_dataframe[drop_dataframe['Season'] == 'Winter']
fall = drop_dataframe[drop_dataframe['Season'] == 'Fall']
spring = drop_dataframe[drop_dataframe['Season'] == 'Spring']
summer = drop_dataframe[drop_dataframe['Season'] == 'Summer']

gp = winter.groupby('Shipping Type')
plt.plot(gp['Purchase Amount (USD)'].mean())

gp = fall.groupby('Shipping Type')
plt.plot(gp['Purchase Amount (USD)'].mean())

gp = spring.groupby('Shipping Type')
plt.plot(gp['Purchase Amount (USD)'].mean())

gp = summer.groupby('Shipping Type')
plt.plot(gp['Purchase Amount (USD)'].mean())

plt.legend(['Winter', 'Fall', 'Spring', 'Summer'])

plt.show()