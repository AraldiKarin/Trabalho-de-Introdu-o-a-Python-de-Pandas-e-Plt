
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data_set = pd.read_csv("dataset.csv")
drop_dataframe = data_set.dropna()

day =drop_dataframe[drop_dataframe['Shipping Type'] == 'Day Shipping']
gpa = day.groupby('Season')
gpa['Customer ID'].count().plot()

express = drop_dataframe[drop_dataframe['Shipping Type'] == 'Express']
gpa = express.groupby('Season')
gpa['Customer ID'].count().plot()

free = drop_dataframe[drop_dataframe['Shipping Type'] == 'Free Shipping']
gpa = free.groupby('Season')
gpa['Customer ID'].count().plot()

nextday = drop_dataframe[drop_dataframe['Shipping Type'] == 'Next Day Air']
gpa = nextday.groupby('Season')
gpa['Customer ID'].count().plot()

standard = drop_dataframe[drop_dataframe['Shipping Type'] == 'Standard']
gpa = standard.groupby('Season')
gpa['Customer ID'].count().plot()

store = drop_dataframe[drop_dataframe['Shipping Type'] == 'Store Pickup']
gpa = store.groupby('Season')
gpa['Customer ID'].count().plot()


plt.legend(['Day Shipp', 'Express', 'Free Shipp', 'Next Day', 'Standard', 'Store'])
plt.show()