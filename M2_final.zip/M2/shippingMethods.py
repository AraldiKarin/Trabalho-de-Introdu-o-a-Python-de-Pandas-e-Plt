import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data_set = pd.read_csv("dataset.csv")
drop_dataframe = data_set.dropna()

females = drop_dataframe[drop_dataframe['Gender'] == 'Female']
females_free_shipping = females[females['Shipping Type'] == 'Free Shipping']
gpa = females_free_shipping.groupby('Review Rating')
gpa['Customer ID'].count().plot()

females = drop_dataframe[drop_dataframe['Gender'] == 'Female']
females_no_free_shipping = females[females['Shipping Type'] != 'Free Shipping']
gpa = females_no_free_shipping.groupby('Review Rating')
gpa['Customer ID'].count().plot()

plt.legend(['Free', 'Others'])
plt.suptitle('Review Rating Females Shipping Methods')
plt.show()