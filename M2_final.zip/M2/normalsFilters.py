import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

##Remove NaN Values
data_set = pd.read_csv("dataset.csv")
drop_dataframe = data_set.dropna()

##First Filter
female_cust = drop_dataframe[drop_dataframe['Gender'] == 'Female']
female_cust.to_csv('femaleCustumer'+ '.csv', index=False)

male_cust = drop_dataframe[drop_dataframe['Gender'] == 'Male']
male_cust.to_csv('maleCustumer'+ '.csv', index=False)


##Second Filter
female_cust_weekly = female_cust[female_cust['Frequency of Purchases'] == 'Weekly']
female_cust_weekly.to_csv('female_cust_weekly'+ '.csv', index=False)

female_cust_weekly_no_credit = female_cust_weekly[female_cust_weekly['Payment Method'] != 'Credit Card']
female_cust_weekly_no_credit.to_csv('female_cust_weekly_no_credit'+ '.csv', index=False)
