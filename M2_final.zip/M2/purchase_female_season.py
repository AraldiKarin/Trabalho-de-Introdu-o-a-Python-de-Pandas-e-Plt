import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

data_set = pd.read_csv("dataset.csv")
drop_dataframe = data_set.dropna()

male_cust = drop_dataframe[drop_dataframe['Gender'] == 'Female']
gp = male_cust.groupby('Season')
plt.plot(gp['Purchase Amount (USD)'].mean())
plt.show()